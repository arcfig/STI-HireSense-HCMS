const { GoogleGenerativeAI } = require('@google/generative-ai');
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const express = require('express');
const router = express.Router();
const Faculty = require('../models/Faculty');
const { cloudinary, upload } = require('../config/cloudinary');
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const Department = require('../models/Department');
const Program = require('../models/Program');
const Subject = require('../models/Subject');

// 1. Import the new jose JWT middleware
const { verifyToken, requireRole } = require('../middleware/authMiddleware');

// --------------------------------------------------------
// ROUTE: AI Document Extraction (Auto-Fill) (Secured: All logged-in users)
// --------------------------------------------------------
router.post('/extract', upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No document provided for extraction." });
    }

    const b64 = Buffer.from(req.file.buffer).toString("base64");
    const filePart = { inlineData: { data: b64, mimeType: req.file.mimetype } };

    const prompt = `You are a highly accurate HR data extraction AI. Read the attached document.
    
    TASK 1: CLASSIFICATION
    Determine the exact document type. You MUST select strictly from one of these six options:
    "201 File", "Certificate", "Faculty Evaluation", "Contract", "Letter of Intent", "Non-Renewal Contract".
    
    TASK 2: STANDARD EXTRACTION
    Extract the person's first name, last name, the exact title of the document, and infer their academic department.
    Also extract the "dateReceived" (YYYY-MM-DD), the "expirationDate" (YYYY-MM-DD, leave blank if none), and the "issuingInstitution".
    
    TASK 3: DYNAMIC METRICS
    - If the document is a "Faculty Evaluation", extract the "academicYear" (e.g., "SY 2025-2026"), "term" (e.g., "Term 1"), and the final overall "evaluationRating" as a number (e.g., 4.35).
    
    STRICT INSTRUCTION REGARDING SKILLS/TAGS:
    - ONLY extract a comma-separated string of key skills or technologies if the document is classified as a "Certificate".
    - For ALL other document types (201 File, Contract, Evaluation, LOI), the "tags" field MUST be an empty string ("").
    
    You MUST return ONLY a valid JSON object. Do not use markdown.
    Example format: {"firstName": "John", "lastName": "Doe", "documentType": "Faculty Evaluation", "documentTitle": "Performance Evaluation", "department": "Information Technology", "dateReceived": "2026-01-26", "expirationDate": "", "issuingInstitution": "STI", "academicYear": "SY 2025-2026", "term": "Term 1", "evaluationRating": 4.35, "tags": ""}`;
    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash",
      generationConfig: {
        responseMimeType: "application/json"
      }
    });

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    let result;
    let retries = 3;

    while (retries > 0) {
      try {
        result = await model.generateContent([prompt, filePart]);
        break;
      } catch (apiError) {
        if (apiError.status === 503 && retries > 1) {
          console.warn(`[Extraction API 503] Server overloaded. Retrying... (${retries - 1} attempts left)`);
          await delay(2500);
          retries--;
        } else {
          throw apiError;
        }
      }
    }

    const rawText = result.response.text();
    let extractedData;

    try {
      extractedData = JSON.parse(rawText);
    } catch (parseError) {
      console.error("Failed to parse Gemini JSON:", rawText);
      return res.status(500).json({ error: "AI returned an unparsable format. Please try again." });
    }

    res.status(200).json(extractedData);

  } catch (error) {
    console.error("Extraction Error:", error);
    res.status(500).json({ error: "Failed to extract data from document due to server load. Please try again." });
  }
});

// --------------------------------------------------------
// ROUTE: Get all 'Pending' profiles (Secured: Admins and Heads Only)
// --------------------------------------------------------
router.get('/pending', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const pendingProfiles = await Faculty.find({ status: 'pending' });
    res.status(200).json(pendingProfiles);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch pending profiles" });
  }
});

// --------------------------------------------------------
// ROUTE: Fetch ONLY Approved Profiles (Secured: All logged-in users)
// --------------------------------------------------------
router.get('/approved', verifyToken, async (req, res) => {
  try {
    const activeUsers = await User.find({ isArchived: { $ne: true } });
    const activeUserNames = activeUsers.map(u => u.name.toLowerCase());

    const approvedProfiles = await Faculty.find({ status: 'approved' }).sort({ createdAt: -1 });

    const activeApprovedProfiles = approvedProfiles.filter(profile => {
      const fullName = `${profile.firstName} ${profile.lastName}`.toLowerCase();
      return activeUserNames.includes(fullName);
    });

    res.status(200).json(activeApprovedProfiles);
  } catch (error) {
    console.error("Error fetching approved profiles:", error);
    res.status(500).json({ error: "Failed to fetch portfolio data." });
  }
});

// --------------------------------------------------------
// ROUTE: Update Profile Status & Trigger Notification (Secured: Admins and Heads)
// --------------------------------------------------------
router.put('/status/:id', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const { id } = req.params;
    const { status, remarks } = req.body;

    const updatedFaculty = await Faculty.findByIdAndUpdate(
      id,
      { status: status, remarks: remarks || '' },
      { new: true }
    );

    if (!updatedFaculty) return res.status(404).json({ error: "Document not found." });

    const fullName = `${updatedFaculty.firstName} ${updatedFaculty.lastName}`;
    const targetUser = await User.findOne({ name: { $regex: new RegExp(`^${fullName}$`, 'i') } });

    if (targetUser) {
      targetUser.notifications.push({
        title: `Document ${status === 'approved' ? 'Approved' : 'Rejected'}`,
        message: `Your document "${updatedFaculty.documentTitle}" has been ${status}. ${remarks ? `HR Remarks: ${remarks}` : ''}`,
        type: status === 'approved' ? 'success' : 'danger'
      });
      await targetUser.save();
    }

    res.status(200).json({ message: `Profile marked as ${status}`, data: updatedFaculty });
  } catch (error) {
    console.error("Status Update Error:", error);
    res.status(500).json({ error: "Failed to update status" });
  }
});

// --------------------------------------------------------
// ROUTE: Edit/Update an existing credential (Secured: Admins and Heads)
// --------------------------------------------------------
router.put('/edit/:id', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const { firstName, lastName, department, documentTitle, documentType, tags } = req.body;

    let updatedTags = tags;
    if (typeof tags === 'string') {
      updatedTags = tags.split(',').map(tag => tag.trim()).filter(tag => tag !== '');
    }

    const updatedFaculty = await Faculty.findByIdAndUpdate(
      req.params.id,
      { firstName, lastName, department, documentTitle, documentType, tags: updatedTags },
      { returnDocument: 'after' }
    );

    if (!updatedFaculty) {
      return res.status(404).json({ error: "Document not found." });
    }

    res.status(200).json({ message: "Document updated successfully!", data: updatedFaculty });
  } catch (error) {
    console.error("Error updating document:", error);
    res.status(500).json({ error: "Failed to update the document." });
  }
});

// --------------------------------------------------------
// ROUTE: AI Candidate Matcher (Secured: Admins and Heads)
// --------------------------------------------------------
router.post('/match', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const { requirements } = req.body;
    if (!requirements) return res.status(400).json({ error: "Please provide job requirements." });

    const User = require('../models/User');
    const [candidates, users] = await Promise.all([
      Faculty.find({ status: 'approved' }),
      User.find({ isArchived: { $ne: true } }, '-passwordHash')
    ]);

    if (candidates.length === 0) return res.status(404).json({ error: "No approved candidates found." });

    const groupedProfiles = candidates.reduce((acc, doc) => {
      const nameKey = `${doc.firstName} ${doc.lastName}`.toUpperCase();
      if (!acc[nameKey]) {
        acc[nameKey] = {
          id: nameKey, name: `${doc.firstName} ${doc.lastName}`, department: doc.department,
          tags: new Set(), documents: []
        };
      }
      if (doc.tags) doc.tags.forEach(tag => acc[nameKey].tags.add(tag));
      if (doc.documentTitle) acc[nameKey].documents.push(doc.documentTitle);
      return acc;
    }, {});

    const candidateData = Object.values(groupedProfiles).map(profile => {
      const matchedUser = users.find(u => u.name.toLowerCase() === profile.name.toLowerCase());
      if (!matchedUser) return null;

      return {
        id: profile.id, name: profile.name, department: profile.department,
        skills: Array.from(profile.tags), skillRatings: matchedUser?.skillRatings || {}, documents: profile.documents
      };
    }).filter(Boolean);

    if (candidateData.length === 0) return res.status(404).json({ error: "No active candidates available for matching." });

    const prompt = `You are an expert HR Candidate Matching AI.
    The HR Department needs a candidate with these requirements: "${requirements}"
    Here is the current pool of aggregated faculty profiles: ${JSON.stringify(candidateData)}
    Rank the best matches. Return ONLY a JSON array of objects formatted exactly like this:
    [{"id": "THE_ID_STRING", "score": 85, "reason": "1-2 short sentences explaining why."}]`;

    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash",
      generationConfig: { responseMimeType: "application/json" }
    });

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    let result;
    let retries = 3;

    while (retries > 0) {
      try {
        result = await model.generateContent(prompt);
        break;
      } catch (apiError) {
        if (apiError.status === 503 && retries > 1) {
          console.warn(`[API 503] Google server overloaded. Retrying... (${retries - 1} attempts left)`);
          await delay(2000);
          retries--;
        } else {
          throw apiError;
        }
      }
    }

    let matchResults;
    try {
      matchResults = JSON.parse(result.response.text());
    } catch (parseError) {
      console.error("Failed to parse Gemini JSON:", result.response.text());
      return res.status(500).json({ error: "AI returned an unparsable format." });
    }

    const finalMatches = matchResults.map(match => {
      const profile = candidateData.find(c => c.id === match.id);
      if (!profile) return null;
      return { ...profile, matchScore: match.score, matchReason: match.reason };
    }).filter(m => m !== null && m.matchScore > 0).sort((a, b) => b.matchScore - a.matchScore);

    res.status(200).json(finalMatches);

  } catch (error) {
    console.error("CRITICAL Backend Matching Error:", error);
    res.status(500).json({ error: "The AI matching engine is currently overloaded. Please try again in a few moments." });
  }
});

// --------------------------------------------------------
// ROUTE: Create Profile + Cloudinary + AI Vision OCR (Secured: All logged-in users)
// --------------------------------------------------------
router.post('/add', verifyToken, upload.single('document'), async (req, res) => {
  try {
    const { firstName, lastName, department, documentTitle, documentType, uploaderRole, autoValidate } = req.body;
    let fileUrl = "";

    if (req.file) {
      const b64 = Buffer.from(req.file.buffer).toString("base64");
      let dataURI = "data:" + req.file.mimetype + ";base64," + b64;

      const cldRes = await cloudinary.uploader.upload(dataURI, {
        resource_type: "auto",
        folder: "HCMS_Certificates"
      });
      fileUrl = cldRes.secure_url;
    }

    let tagsArray = [];

    if (documentType === 'Certificate') {
      let aiInput = [];

      if (req.file) {
        const b64 = Buffer.from(req.file.buffer).toString("base64");
        const filePart = { inlineData: { data: b64, mimeType: req.file.mimetype } };
        const prompt = `You are a highly accurate HR data extraction AI. Read the attached document. Extract a list of key skills, certifications, and technologies. Return ONLY a JSON object containing a "tags" array of strings. Example: {"tags": ["Java", "Cloud Computing"]}`;

        aiInput = [prompt, filePart];
      } else {
        const prompt = `Generate exactly 3 professional skill tags for a faculty member in the ${department} department. Return ONLY a JSON object containing a "tags" array of strings.`;

        aiInput = [prompt];
      }

      const model = genAI.getGenerativeModel({
        model: "gemini-2.5-flash",
        generationConfig: { responseMimeType: "application/json" }
      });

      const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
      let result = null;
      let retries = 3;

      while (retries > 0) {
        try {
          result = await model.generateContent(aiInput);
          break;
        } catch (apiError) {
          if (apiError.status === 503 && retries > 1) {
            console.warn(`[Add API 503] Server overloaded. Retrying... (${retries - 1} attempts left)`);
            await delay(2500);
            retries--;
          } else {
            console.error(`[AI Bypass] Gemini API failed: ${apiError.message}. Proceeding without secondary AI tags.`);
            break;
          }
        }
      }

      if (result) {
        try {
          const aiText = result.response.text();
          const parsedData = JSON.parse(aiText);
          tagsArray = parsedData.tags || [];
        } catch (parseError) {
          console.error("Failed to parse Gemini output in /add route:", parseError);
        }
      }
    }

    const finalStatus = (['hr', 'admin', 'academic_head', 'program_head'].includes(uploaderRole) && autoValidate === 'true') ? 'approved' : 'pending';

    const firstWord = firstName.trim().split(/\s+/)[0];
    const lastWords = lastName.trim().split(/\s+/);
    const lastWord = lastWords[lastWords.length - 1];

    const nameRegex = new RegExp(`^${firstWord}\\b.*\\b${lastWord}$`, 'i');
    const existingUser = await User.findOne({ name: { $regex: nameRegex } });

    const fullName = `${firstName} ${lastName}`;

    if (!existingUser) {
      const baseUsername = `${firstName.toLowerCase().replace(/\s+/g, '')}.${lastName.toLowerCase().replace(/\s+/g, '')}`;
      let uniqueUsername = baseUsername;
      let counter = 1;
      while (await User.findOne({ username: uniqueUsername })) {
        uniqueUsername = `${baseUsername}${counter}`;
        counter++;
      }

      const defaultPassword = "STI_password123";
      const hashedPassword = await bcrypt.hash(defaultPassword, 10);

      const newUser = new User({
        name: fullName, username: uniqueUsername, passwordHash: hashedPassword, role: 'faculty'
      });
      await newUser.save();
    }

    let formattedTags = tagsArray;
    if (req.body.tags) {
      let frontendTags = [];
      if (typeof req.body.tags === 'string') {
        frontendTags = req.body.tags.split(',').map(tag => tag.trim()).filter(tag => tag !== "");
      } else if (Array.isArray(req.body.tags)) {
        frontendTags = req.body.tags;
      }
      formattedTags = [...new Set([...formattedTags, ...frontendTags])];
    }

    const newFaculty = new Faculty({
      firstName, lastName, department,
      documentTitle,
      documentType,
      issuingInstitution: req.body.issuingInstitution,
      dateReceived: req.body.dateReceived,
      expirationDate: req.body.expirationDate,
      documentUrl: fileUrl,
      tags: formattedTags,
      status: finalStatus,

      academicYear: req.body.academicYear || '',
      term: req.body.term || '',
      contractStart: req.body.contractStart || '',
      contractEnd: req.body.contractEnd || '',
      intent: req.body.intent || '',
      offenseType: req.body.offenseType || '',
      evaluationRating: req.body.evaluationRating ? parseFloat(req.body.evaluationRating) : null
    });

    const savedFaculty = await newFaculty.save();
    res.status(201).json({ message: "Profile & Document submitted!", data: savedFaculty });

  } catch (error) {
    console.error("Upload Error:", error);
    res.status(500).json({ error: "Failed to process submission", details: error.message });
  }
});

// --------------------------------------------------------
// ROUTE: Get Subject Hierarchy (Secured: Admins and Heads)
// --------------------------------------------------------
router.get('/subjects/hierarchy', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const subjects = await Subject.find()
      .populate('programId', 'name')
      .populate('departmentId', 'name');

    const hierarchy = subjects.reduce((acc, sub) => {
      if (!sub.departmentId || !sub.programId) return acc;

      const dept = sub.departmentId.name;
      const prog = sub.programId.name;

      if (!acc[dept]) acc[dept] = {};
      if (!acc[dept][prog]) acc[dept][prog] = [];

      acc[dept][prog].push({
        courseCode: sub.courseCode,
        subjectName: sub.subjectName
      });

      return acc;
    }, {});

    res.status(200).json(hierarchy);
  } catch (error) {
    console.error("Hierarchy Error:", error);
    res.status(500).json({ error: "Failed to retrieve subject hierarchy." });
  }
});

// --------------------------------------------------------
// ROUTE: Get Eligible Faculty by Course Code (Secured: Admins and Heads)
// --------------------------------------------------------
router.get('/subjects/:courseCode/faculty', verifyToken, requireRole(['admin', 'academic_head', 'program_head']), async (req, res) => {
  try {
    const { courseCode } = req.params;

    const eligibleFaculty = await Faculty.find({
      eligibleSubjects: courseCode,
      status: 'approved'
    }).select('firstName lastName department tags');

    res.status(200).json(eligibleFaculty);
  } catch (error) {
    console.error("Eligibility Fetch Error:", error);
    res.status(500).json({ error: "Failed to retrieve eligible faculty." });
  }
});



// --------------------------------------------------------
// ROUTE: Fetch User Notifications (Secured: All logged-in users)
// --------------------------------------------------------
router.get('/notifications/:username', verifyToken, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username });
    if (!user) return res.status(404).json({ error: "User not found." });

    const sortedNotifications = user.notifications.sort((a, b) => b.date - a.date);
    res.status(200).json(sortedNotifications);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch notifications." });
  }
});

// --------------------------------------------------------
// ROUTE: Mark Notifications as Read (Secured: All logged-in users)
// --------------------------------------------------------
router.put('/notifications/:username/read', verifyToken, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username });
    if (!user) return res.status(404).json({ error: "User not found." });

    user.notifications.forEach(notif => notif.isRead = true);
    await user.save();

    res.status(200).json({ message: "Notifications marked as read." });
  } catch (error) {
    res.status(500).json({ error: "Failed to update notifications." });
  }
});

module.exports = router;